"""
Niniejszy moduł zawiera definicję funkcji szescian()
"""

def szescian(x):
    "Wyznacza sześcian danej liczby."
    return x ** 3
