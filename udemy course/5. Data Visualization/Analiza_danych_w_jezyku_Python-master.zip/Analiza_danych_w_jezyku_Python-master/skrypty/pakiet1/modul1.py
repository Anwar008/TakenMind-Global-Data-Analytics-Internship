"""
Niniejszy moduł zawiera definicję funkcji kwadrat()
"""

def kwadrat(x):
    "Wyznacza kwadrat danej liczby."
    return x ** 2
