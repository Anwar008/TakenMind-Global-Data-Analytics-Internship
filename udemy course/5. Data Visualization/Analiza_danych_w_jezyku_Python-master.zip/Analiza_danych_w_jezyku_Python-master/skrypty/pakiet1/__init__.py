"""
To jest mój pierwszy pakiet.
"""
