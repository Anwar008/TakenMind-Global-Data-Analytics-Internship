zmienna = 1
print("Mój pierwszy skrypt: %d" % zmienna)
