"""
To jest mój pierwszy moduł. Niniejszy napis (docstring)
stanowi jego dokumentację.
"""

print("Ładuję moduł o nazwie: " + __name__)

zmienna1    = 1
__zmienna2  = 2

def funkcja(x):
    "Podnosi do kwadratu daną liczbę."
    return x**2
