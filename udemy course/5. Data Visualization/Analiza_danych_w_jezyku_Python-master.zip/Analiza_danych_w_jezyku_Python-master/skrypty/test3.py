import os
print("__file__ = " + __file__)
print("__name__ = " + __name__)
